package com.example.qpg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionPaperGeneratorApplication {

	public static void main(String[] args) {
        loadEnv();
		SpringApplication.run(QuestionPaperGeneratorApplication.class, args);
	}

    private static void loadEnv() {
        try {
            java.nio.file.Path path = java.nio.file.Paths.get(".env");
            if (java.nio.file.Files.exists(path)) {
                java.util.List<String> lines = java.nio.file.Files.readAllLines(path);
                for (String line : lines) {
                    if (line.trim().isEmpty() || line.trim().startsWith("#")) {
                        continue;
                    }
                    String[] parts = line.split("=", 2);
                    if (parts.length == 2) {
                        String key = parts[0].trim();
                        String value = parts[1].trim();
                        System.setProperty(key, value);
                    }
                }
                System.out.println("Loaded environment variables from .env file");
            } else {
                System.out.println(".env file not found, skipping loading.");
            }
        } catch (Exception e) {
            System.err.println("Failed to load .env file: " + e.getMessage());
        }
    }

}
