package com.example.qpg.service;

import com.example.qpg.model.Question;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<Question> generateQuestions(String subject, String difficulty, int count) {
        String prompt = String.format("Generate %d %s level questions for the subject '%s'. " +
                "Format the output as a JSON array of objects with fields: 'content' (the question text), " +
                "'type' (e.g., MCQ, Descriptive), 'difficulty' (Easy, Medium, Hard), and 'subject'. " +
                "Do not include any markdown formatting or code blocks, just the raw JSON array.", 
                count, difficulty, subject);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        try {
            // Safe JSON construction
            ObjectMapper requestMapper = new ObjectMapper();
            ObjectNode contentPart = requestMapper.createObjectNode();
            contentPart.put("text", prompt);
            
            ArrayNode partsArray = requestMapper.createArrayNode();
            partsArray.add(contentPart);
            
            ObjectNode contentNode = requestMapper.createObjectNode();
            contentNode.set("parts", partsArray);
            
            ArrayNode contentsArray = requestMapper.createArrayNode();
            contentsArray.add(contentNode);
            
            ObjectNode requestBodyNode = requestMapper.createObjectNode();
            requestBodyNode.set("contents", contentsArray);
            
            String requestBody = requestMapper.writeValueAsString(requestBodyNode);

            HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
            
            int maxRetries = 3;
            long retryDelayMs = 2000; // Start with 2 seconds

            for (int attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    System.out.println("Sending request to Gemini API (Attempt " + attempt + "/" + maxRetries + ")...");

                    ResponseEntity<String> response = restTemplate.exchange(
                            apiUrl + "?key=" + apiKey,
                            HttpMethod.POST,
                            entity,
                            String.class
                    );

                    System.out.println("Gemini API Response Code: " + response.getStatusCode());
                    
                    if (!response.getStatusCode().is2xxSuccessful()) {
                        throw new RuntimeException("Gemini API returned error: " + response.getStatusCode());
                    }

                    return parseGeminiResponse(response.getBody(), subject, difficulty);

                } catch (org.springframework.web.client.HttpServerErrorException | org.springframework.web.client.HttpClientErrorException e) {
                    // 503 Service Unavailable or 429 Too Many Requests
                    if (e.getStatusCode().value() == 503 || e.getStatusCode().value() == 429) {
                        System.err.println("Gemini API overloaded or limited: " + e.getMessage());
                        if (attempt == maxRetries) {
                            throw new RuntimeException("Gemini API failed after " + maxRetries + " attempts: " + e.getMessage(), e);
                        }
                        System.out.println("Retrying in " + retryDelayMs + "ms...");
                        try {
                            Thread.sleep(retryDelayMs);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            throw new RuntimeException("Interrupted during retry wait", ie);
                        }
                        retryDelayMs *= 2; // Exponential backoff
                    } else {
                        // Other errors (e.g., 400 Bad Request, 401 Unauthorized) - do not retry
                        throw new RuntimeException("Gemini API Error: " + e.getMessage(), e);
                    }
                } catch (org.springframework.web.client.ResourceAccessException e) {
                    // Network errors (timeouts, connection refused)
                    System.err.println("Network error accessing Gemini API: " + e.getMessage());
                    if (attempt == maxRetries) {
                        throw new RuntimeException("Network error after " + maxRetries + " attempts: " + e.getMessage(), e);
                    }
                    System.out.println("Retrying in " + retryDelayMs + "ms...");
                    try {
                        Thread.sleep(retryDelayMs);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                    retryDelayMs *= 2;
                } catch (Exception e) {
                    System.err.println("Unexpected error calling Gemini API: " + e.getMessage());
                    e.printStackTrace();
                    throw new RuntimeException("Failed to generate questions: " + e.getMessage(), e);
                }
            }
            throw new RuntimeException("Failed to generate questions after retries.");
        } catch (Exception e) {
             // Catch-all for JSON errors or other unexpected issues
             System.err.println("Error in generateQuestions: " + e.getMessage());
             e.printStackTrace();
             // Ensure it's passed up as a RuntimeException
             if (e instanceof RuntimeException) {
                 throw (RuntimeException) e;
             }
             throw new RuntimeException("Paper generation failed: " + e.getMessage(), e);
        }
    }
    private List<Question> parseGeminiResponse(String responseBody, String subject, String difficulty) {
        List<Question> questions = new ArrayList<>();
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode candidates = root.path("candidates");
            if (candidates.isArray() && candidates.size() > 0) {
                String text = candidates.get(0).path("content").path("parts").get(0).path("text").asText();
                
                // Remove potential markdown code blocks if any remain
                text = text.replaceAll("```json", "").replaceAll("```", "").trim();
                
                // Use regex to find the JSON array in case of extra text
                Pattern pattern = Pattern.compile("\\[.*\\]", Pattern.DOTALL);
                Matcher matcher = pattern.matcher(text);
                
                if (matcher.find()) {
                    String jsonArray = matcher.group();
                    JsonNode questionsNode = objectMapper.readTree(jsonArray);
                    
                    if (questionsNode.isArray()) {
                        for (JsonNode node : questionsNode) {
                            Question q = new Question();
                            q.setContent(node.path("content").asText());
                            q.setType(node.path("type").asText("Descriptive"));
                            q.setDifficulty(node.path("difficulty").asText(difficulty));
                            q.setSubject(node.path("subject").asText(subject));
                            questions.add(q);
                        }
                    }
                } else {
                    System.err.println("No JSON array found in Gemini response text: " + text);
                    // Attempt to parse text directly if it is just a JSON array
                     try {
                        JsonNode questionsNode = objectMapper.readTree(text);
                        if (questionsNode.isArray()) {
                            for (JsonNode node : questionsNode) {
                                Question q = new Question();
                                q.setContent(node.path("content").asText());
                                q.setType(node.path("type").asText("Descriptive"));
                                q.setDifficulty(node.path("difficulty").asText(difficulty));
                                q.setSubject(node.path("subject").asText(subject));
                                questions.add(q);
                            }
                        }
                    } catch (Exception ex) {
                         System.err.println("Fallback parsing failed: " + ex.getMessage());
                    }
                }
            } else {
                 System.err.println("No candidates in Gemini response. Response body: " + responseBody);
            }
        } catch (Exception e) {
            System.err.println("Error parsing Gemini response: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to parse Gemini response: " + e.getMessage());
        }
        return questions;
    }
}
